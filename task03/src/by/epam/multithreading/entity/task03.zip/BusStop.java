//package by.epam.multithreading.entity;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class BusStop {
	
	public static int MAX_NUM_OF_BUS = 2;
	//private final Lock lock = new ReentrantLock();
	
	String stopName;
	// текущее колич людей на остановке
	volatile int numOfPeople;
	// список автобусов на остановке
	BlockingQueue<Bus> currentBuses;
	
	public BusStop(String name) {
		stopName = name;
		numOfPeople = 0;
		currentBuses = new LinkedBlockingQueue<Bus>(MAX_NUM_OF_BUS);
	}
	
	public void setNumOfPeople(int num) {
		numOfPeople = num;
	}
	
	public int getNumOfPeople() {
		return numOfPeople;
	}
	
	public void setCurrentBuses(BlockingQueue<Bus> buses) {
		currentBuses = buses;
	}
	
	public BlockingQueue<Bus> getCurrentBuses() {
		return currentBuses;
	}
}
