//package by.epam.multithreading.entity;

import java.util.List;
import java.util.LinkedList;
import java.util.Iterator;
import java.util.Random;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Bus implements Runnable {
	
	private final Lock lock = new ReentrantLock();
	public static int MAX_CAPACITY = 30;
	
	// номер автобуса
	private String name;
	// текущее колич пассажиров
	private int capacity;
	// маршрут
	private List<BusStop> stops;
	
	public Bus(String name) {
		this.name = name;
		capacity = 0;
		stops = new LinkedList<BusStop>();
	}
	
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
	
	public int getCapacity() {
		return capacity;
	}
	
	public void setStops(List<BusStop> stops) {
		this.stops = stops;
	}
	
	public List<BusStop> getStops() {
		return stops;
	}
	
	@Override
	public void run() {
		try {
			BusStop stop;
			Iterator<BusStop> iter = stops.iterator();
			Bus previousBus;
			
			Random rand = new Random();
			int num;
			
			while(iter.hasNext()) {
				//Thread.sleep(1_000);
				TimeUnit.SECONDS.sleep(1);
				
				stop = iter.next();
				
				// автобус остановился у остановки
				//stop.addBus(this);
				// or
				stop.getCurrentBuses().put(this);
				
				System.out.println(name + " arrived");
				
				System.out.println("Bus " + name + ": " + capacity);
				System.out.println("Stop: " + stop.getNumOfPeople());
				
				lock.lock();
				
				// автобус высаживает людей на остановку
				num = rand.nextInt(capacity+1);
				capacity -= num;
				stop.setNumOfPeople(stop.getNumOfPeople() + num);
				//stop.numOfPeople += num;
				System.out.println(name + " => stop: " + num);
				
				// автобус забирает людей с остановки
				num = rand.nextInt(MAX_CAPACITY - capacity) % stop.getNumOfPeople();
				capacity += num;
				stop.setNumOfPeople(stop.getNumOfPeople() - num);
				//stop.numOfPeople -= num;
				System.out.println(name + " <= stop: " + num);
				
				lock.unlock();
				
				System.out.println("Bus " + name + ": " + capacity);
				System.out.println("Stop: " + stop.getNumOfPeople());
				
				// автобус покинул остановку
				//stop.removeBus(this);
				stop.getCurrentBuses().remove(this);
				System.out.println(name + " left");
				
				// едет дальше
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
