//package by.epam.multithreading.entity;

import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;

public class Main {
	public static void main(String[] args) throws InterruptedException {
		
		BusStop stop = new BusStop("stop");
		stop.setNumOfPeople(30);
		
		Bus bus1 = new Bus("1");
		Bus bus2 = new Bus("2");
		Bus bus3 = new Bus("3");
		
		bus1.getStops().add(stop);
		bus2.getStops().add(stop);
		bus3.getStops().add(stop);
		
		ExecutorService es = Executors.newFixedThreadPool(3);
		
		es.execute(bus1);
		es.execute(bus2);
		es.execute(bus3);
		
		es.shutdown();
	}
}
